# rbsp-efw-fbk-frequency-enhancer
Uses the overlapping RBSP filterbank gain curves to enhance the FBK freq resolution and adjust the amplitudes
